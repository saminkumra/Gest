#ifndef ESP32_BLE_COMBO_H
#define ESP32_BLE_COMBO_H
#include "BleComboKeyboard.h"
#include "BleComboMouse.h"

extern BleComboMouse Mouse;
extern BleComboKeyboard Keyboard;

#endif
